# BloxflipPredictor
The most efficient and safe bloxflip predictor out there, crash, mines, towers, cups predictor.

• Discord Webhook support (get next game's results via Discord server.

• Telegram Notifier (Specify your ID and bot's token, and you will receive messages via Telegram)

• Works for all games

• Lightweight (doesn't use too much PC resources)

• Extremely fast (get a result for the next game in a second)

• Auto play (You can turn this and specify robux amount you want to play with and software will play instead of you)

• Loss detector (If you lose more than x Robux, bot will turn off itself to prevent loses. This is usually a rare case so you can keep this off)

• Fully customizable

• No python required

• Simple download

• Undetected

# How to launch?

• Install the file

• Launch the .exe

• Loading could take up to 30 seconds

• And you're done, enjoy!

# Preview

![image](https://user-images.githubusercontent.com/117777701/201475116-cb69493c-4771-4411-8401-08bf16615257.png)
![image](https://user-images.githubusercontent.com/117777701/201475174-b1f36827-8dd3-484c-be28-d7588823401e.png)

https://www.youtube.com/watch?v=8Wg5oh0v_m8&t=19s
